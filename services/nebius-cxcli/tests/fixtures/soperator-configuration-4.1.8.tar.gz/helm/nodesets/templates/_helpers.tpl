{{/*
Expand the name of the chart.
*/}}
{{- define "nodesets.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "nodesets.fullname" -}}
{{- default .Release.Name .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "nodesets.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "nodesets.labels" -}}
helm.sh/chart: {{ include "nodesets.chart" . }}
{{ include "nodesets.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "nodesets.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nodesets.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "nodesets.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "nodesets.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/* Construct container gpu resource from GPU spec ([0]) and GPU resource spec ([1]) */}}
{{- define "nodesets.resource.gpuFrom" -}}
  {{- $gpuSpec := (index . 0) | default dict -}}
  {{- $gpuEnabled := get $gpuSpec "enabled" | default false -}}
  {{- if not $gpuEnabled -}}
    {{- "" -}}
  {{- else -}}
    {{- $gpuVendorNvidia := hasKey $gpuSpec "nvidia" -}}
    {{- $gpuVendor := $gpuVendorNvidia | ternary "nvidia.com" "" -}}
    {{- $gpuResFQID := $gpuVendor | empty | ternary "gpu" (printf "%s/gpu" $gpuVendor)}}
    {{- $resources := required ".Values.nodesets[*].slurmd.resources.gpu is required as .Values.nodesets[*].gpu.enabled is true" (index . 1)}}
{{ $gpuResFQID }}: {{ get $resources "gpu" }}
  {{- end -}}
{{- end -}}
